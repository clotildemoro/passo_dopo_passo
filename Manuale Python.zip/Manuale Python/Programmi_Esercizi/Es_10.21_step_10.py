h=1 #Inizializziamo varibile contatore.
while h <= 2: #Impostiamo un ciclo con condizione h minore o uguale a 2.
    i=j=n=1 #Inizializziamo le varibili contatori per i seguenti cicli.
    while i <= 6:#Impostiamo un ciclo con condizione h minore o uguale a 6.
        print ('verde')#Stampiamo la parola verde.
        i=i+1#Incrementiamo la varible contatore.
    while j <= 2:#Impostiamo un ciclo con condizione j minore o uguale a 2.
        print ('giallo') #Visualizziamo la parola giallo.
        j=j+1 #Incrementiamo la varible contatore.
    while n <=4 : #Impostiamo un ciclo con condizione n minore o uguale a 4.
        print ('rosso') #Stampiamo la parola rosso.
        n=n+1#Incrementiamo la varible contatore.
    h=h+1#Incrementiamo la varible contatore.
