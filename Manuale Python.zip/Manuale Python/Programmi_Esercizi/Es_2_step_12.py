# il ciao di Clotilde 
import pygame
import math
import time
pygame.init()

def ciao():
	surface.fill ((0,0,0))
	pygame.draw.line(surface, (255,255,0),(60,110), (120, 110))
	pygame.draw.line(surface, (255,255,0),(60,110), (60,210))
	pygame.draw.line(surface, (255,255,0),(60,210), (120, 210))
	pygame.display.update()
	time.sleep(1)
	surface.fill ((0,0,0))
	pygame.draw.line(surface, (255,255,0),(140,110), (140,210))
	pygame.display.update()
	time.sleep(1)
	surface.fill ((0,0,0))
	pygame.draw.line(surface, (255,255,0),(160,110), (220, 110))
	pygame.draw.line(surface, (255,255,0),(160,160), (220, 160))
	pygame.draw.line(surface, (255,255,0),(160,110), (160,210))
	pygame.draw.line(surface, (255,255,0),(220,110), (220,210))
	pygame.display.update()
	time.sleep(1)
	surface.fill ((0,0,0))
	pygame.draw.line(surface, (255,255,0),(240,110), (300,110))
	pygame.draw.line(surface, (255,255,0),(240,210), (300,210))
	pygame.draw.line(surface, (255,255,0),(240,110), (240,210))
	pygame.draw.line(surface, (255,255,0),(300,110), (300,210))
	pygame.display.update()
	time.sleep(1)
surface=pygame.display.set_mode((600,600))
i=0
while i < 2:
	ciao()
	i=i+1
