def somma(uno, due): #Definiamo una funzione.
    somma = stringauno + stringadue #Dentro somma mettiamo la concatenazione delle due stringhe.
    print ("La concatenazione di ", stringauno, "e ", stringadue, "e' ", somma) #Infine visualizziamo il tutto.
stringauno = input("Inserisci il primo nome ") #Facciamo inserire la prima stringa.
stringadue = input("Inserisci il secondo nome ") #Facciamo inserire la seconda stringa.
somma(stringauno,stringadue) #Richiamiamo la funzione somma.
