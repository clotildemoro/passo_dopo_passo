import math #Importiamo la libreria per eseguire le operazioni matematiche.
numero = int(input ("Scrivi il quadrato di un numero  ")) #Facciamo inserire in input ul quadrato di un numero.
radice = math.sqrt(numero) #Nella variabile radice andiamo a inserire la radice quadrata del numero inserito.
print ("La radice quadrata di ", numero, "e' ", radice) #Infine facciamo visualizzare il risultato.
