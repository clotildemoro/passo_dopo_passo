i=5 #Inizializziamo la variabile contatore.
while i>0: #Impostiamo il primo ciclo con condizione i maggiore di o.
        print (i)#Stampiamo il valore di i.
        i=i-1 #Decrementiamo la variabile contatore.
while i < 4: #Impostiamo il secondo ciclo con condizione i minore di 4.
        print (i+2) #Visualizziamo il valore di i sommato a 2.
        i=i+1 #Incrementiamo la varibile contatore.
