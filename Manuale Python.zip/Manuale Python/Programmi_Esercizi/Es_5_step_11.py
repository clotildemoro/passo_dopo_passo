for n in list(range(2, 20)): #Per n nell'intervallo 2-19.
     for x in list(range(2, n)): #Per x nella lista da 0 a 19.
         if n % x == 0: #Se il resto din con x e' uguale a zero.
             print (n, "e' uguale a, x, '*'", n/x) #Se non e' primo gli diciamo con quali potenze si forma.
             break #Interrompiamo la selezione e passiamo al'istruzione successiva.
     else: #Altrimenti
         print (n, "e' un numero primo") #Andiamo a stampare il numero con una frase.
