uno = int(input ("Scrivi il primo numero  ")) #Facciamo inserire in input il primo valore.
due = int(input ("Scrivi il secondo numero  ")) #Facciamo inserire in input il secondo valore.
tre = int(input ("Scrivi il terzo numero  ")) #Facciamo inserire in input il terzo valore.
somma = uno + due + tre #Il risultato dell'addizione andiamo a metterlo in somma.
sommaquadrati = uno**2 + due**2 + tre**2 #Il risultato del prodotto andiamo a metterlo nella variabile sommaquadrati.
quadratosomma = (uno + due + tre)**2 #Eseguiamo il quadrato dell'operazione somma.
print ("Se sommiamo ", uno, "e ", due, "e ", tre, "si ottiene", somma) #Visualizziamo il risultato contenuto in somma.
print ("La somma dei quadrati dei 3 numeri e' ", sommaquadrati) #Visualizziamo il contenuto di sommaquadrati.
print ("Il quadrato della somma dei 3 numeri e' ", quadratosomma) #Stampiamo il risultato di quadratosomma.
