base = int(input ("Scrivi il valore della base del rettangolo  ")) #L'utente inserisce il valore della base.
altezza = int(input ("Scrivi il valore dell'altezza del rettangolo  ")) #L'utente inserisce il valore dell'altezza.
area = base*altezza #Nella variabile area andiamo a calcolare appunto l'area del rattangolo.
print ("L'area del rettangolo di base ", base, "e altezza ", altezza, "e' ", area) #In conclusione gli diciamo il risultato.
