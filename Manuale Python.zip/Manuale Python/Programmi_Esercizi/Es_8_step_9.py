def calcolo(uno, due, tre): #Definiamo la funzione calcolo.
    area = 2*(uno*due + due*tre + uno*tre) #Dentro la variabile area mettiamo il risultato dell'operazione a destra dell'uguale.
    volume = uno * due * tre #Dentro la varibile volume invece ci inseriamo il prodotto della moltiplicazionea a destra dell'uguale.
    print ("La superficie del parallelpipedo di dimensioni ", uno, due, tre, "e' ", area) #Gli dichiariamo il risultato.
    print ("il volume del parallelpipedo di dimensioni ", uno, due, tre, "e' ", volume) #Stampiamo il volume ottenuto.
uno = float(input("Inserisci la prima dimensione del parallelpipedo rettangolo "))#Facciamo inserire in input il primo valore.
due = float(input("Inserisci la seconda dimensione del parallelpipedo rettangolo ")) #Facciamo inserire in input il secondo valore.
tre = float(input("Inserisci la terza dimensione del parallelpipedo rettangolo ")) #Facciamo inserire in input il terzo valore.
calcolo(uno, due, tre) #Richiamo la funzione calcolo.
