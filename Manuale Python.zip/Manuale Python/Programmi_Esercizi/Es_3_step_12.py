# L'orologio di Angelo

import pygame
import math
import time

pygame.init()

def orologio():
	surface.fill ((0,0,0))
	pygame.draw.circle(surface,(200,0,0),(95,100),60,1)
	pygame.draw.line(surface, (255,255,0),(95,100), (95, 50))
	pygame.display.update()
	time.sleep(2)
	surface.fill ((0,0,0))
	pygame.draw.circle(surface,(200,0,0),(95,100),60,1)
	pygame.draw.line(surface, (255,255,0),(95,100), (145, 100))
	pygame.display.update()
	time.sleep(2)
	surface.fill ((0,0,0))
	pygame.draw.circle(surface,(200,0,0),(95,100),60,1)
	pygame.draw.line(surface, (255,255,0),(95,100), (95, 150))
	pygame.display.update()
	time.sleep(2)
	surface.fill ((0,0,0))
	pygame.draw.circle(surface,(200,0,0),(95,100),60,1)
	pygame.draw.line(surface, (255,255,0),(95,100), (45, 100))
	pygame.display.update()
	time.sleep(2)
surface=pygame.display.set_mode((600,600))
pygame.draw.circle(surface,(200,0,0),(95,100),60,1)
i=0
while i < 5:
	orologio()
	i=i+1
