#Gli chiediamo di inserire gli input della giornata corrente.
pioggia = input ("piove ? (s/n) ")
neve = input ("nevica ? (s/n) ")
freddo = input ("fa freddo ? (s/n) ")
#Grazie agli input raccolti con delle selezioni possiamo dare i consigli.
if pioggia == 's' or neve == 's': #Se la pioggia o la neve hanno risposta positiva.
	print ("prendi l'ombrello") #Gli consigliamo di prendere l'ombrello.
if freddo == 's': #Se fa freddo.
	print ("metti il cappotto") #Giustamente deve prendere il cappotto.
if pioggia == 's' and not freddo =='s': #Se pioggia ha risposta si e freddo no.
	print ("metti la giacca") #Deve mettere la giacca.
if not pioggia == 's' and not neve == 's' and not freddo == 's': #Se non piove, non nevica,non fa freddo.
	print ("vestiti leggero") #Puo vestirsi leggero.
