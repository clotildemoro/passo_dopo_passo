def scacchiera ():
     print ('\t 1 \t 2 \t 3 \n')
     print ('a \t', a1, '\t', a2, '\t', a3, '\n')
     print ('b \t', b1, '\t', b2, '\t', b3, '\n')
     print ('c \t', c1, '\t', c2, '\t', c3, '\n')

#Funzione che effettua il controllo della vittoria
     
def vittoria (n):
     if ((a1 == n and a2 == n and a3 == n) or (b1 == n and b2 == n and b3 == n) or
        (c1 == n and c2 == n and c3 == n) or
       (a1 == n and b1 == n and c1 == n) or (a2 == n and b2 == n and c2 == n) or
       (a3 == n and b3 == n and c3 == n) or
       (a1 == n and b2 == n and c3 == n) or (a3 == n and b2 == n and c1 == n)):
          EsisteVincitore = 'si'
     else:
          EsisteVincitore = 'no'
     return EsisteVincitore

# Inizializzo la scacchiera mettendo  x nelle 9 caselle
a1 = 'x'
a2 = 'x'
a3 = 'x'
b1 = 'x'
b2 = 'x'
b3 = 'x'
c1 = 'x'
c2 = 'x'
c3 = 'x'

scacchiera ()            # visualizzo la scacchiera

partitafinita = 'no'     # inizializzo la variabile che indica quando la partita e' finita
nmosse = 0             # inizializzo la variabile nmosse che conta il numero delle mosse fatte dai giocatori
                                   
print ('Il primo giocatore sarÃ  N \n')

while nmosse < 9 :
               print ('Muova N \n')
               mossafatta = 'no'
               x = input ('Dove vuoi scrivere N: a1, a2, a3, b1, b2, b3, c1, c2, c3? \n')
               if x == 'a1' and a1 == 'x':
                    a1 = 'N'
                    mossafatta = 'si'
               elif x == 'a2' and a2 == 'x':
                    a2 = 'N'
                    mossafatta ='si'
               elif x == 'a3' and a3 == 'x':
                    a3 = 'N'
                    mossafatta ='si'
               elif x == 'b1' and b1 =='x':
                    b1 = 'N'
                    mossafatta ='si'
               elif x == 'b2' and b2 == 'x':
                    b2 = 'N'
                    mossafatta ='si'
               elif x == 'b3' and b3 == 'x':
                    b3 = 'N'
                    mossafatta ='si'
               elif x == 'c1' and c1 == 'x':
                    c1 = 'N'
                    mossafatta ='si'
               elif x == 'c2' and c2 == 'x':
                    c2 = 'N'
                    mossafatta ='si'
               elif x == 'c3' and c3 == 'x':
                    c3 = 'N'
                    mossafatta ='si'
                    
               if mossafatta == 'no':
                    print ('SQUALIFICATO!')
                    partitafinita = 'si'
                    nmosse = 10
                    
               scacchiera ()
               nmosse = nmosse + 1
               partitafinita = vittoria ('N')

               if partitafinita == 'si':
                    print ('Ha vinto N \n')
                    nmosse = 10
               elif   nmosse == 9:
                    print ('PAREGGIO')
                    nmosse = 10

               if partitafinita == 'no' and nmosse < 9:
                    nmosse = nmosse +1
                    mossafatta = 'no'
                    print ('La mossa tocca a R \n')
                    x = input ('Dove vuoi scrivere R: a1, a2, a3, b1, b2, b3, c1, c2, c3? \n')
                    if x == 'a1' and a1 == 'x':
                         a1 = 'R'
                         mossafatta = 'si'
                    elif x == 'a2'and a2 == 'x':
                         a2 = 'R'
                         mossafatta = 'si'
                    elif x == 'a3'and a3 == 'x':
                         a3 = 'R'
                         mossafatta = 'si'
                    elif x == 'b1'and b1 == 'x':
                         b1 = 'R'
                         mossafatta = 'si'
                    elif x == 'b2'and b2 == 'x':
                         b2 = 'R'
                         mossafatta = 'si'
                    elif x == 'b3'and b3 == 'x':
                         b3 = 'R'
                         mossafatta = 'si'
                    elif x == 'c1'and c1 == 'x':
                         c1 = 'R'
                         mossafatta = 'si'
                    elif x == 'c2'and c2 == 'x':
                         c2 = 'R'
                         mossafatta = 'si'
                    elif x == 'c3'and c3 == 'x':
                         c3 = 'R'
                         mossafatta = 'si'

                    if mossafatta == 'no':
                         print ('SQUALIFICATO!')
                         partitafinita = 'si'
                         nmosse = 10
                         
                    scacchiera ()
                    partitafinita = vittoria ('R')
                    if partitafinita == 'si':
                         print ('Ha vinto R \n')
                         nmosse = 10
