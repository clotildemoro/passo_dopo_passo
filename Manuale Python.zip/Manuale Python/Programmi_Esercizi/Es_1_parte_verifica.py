numeri = int(input('Quanti numeri vuoi ordinare?\n')) #Gli chiediamo quanti numeri vuole inserire e quindi ordinare.
a = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] #Creiamo la lista dove andremo a mettere successivamente i numeri inseriti.
i=0 #Inizializziamo la varibile contatore che useremo nel primo ciclo.
print ('inserisci i numeri che vuoi ordinare decrescente (max 15)\n') #Avvertiamo l'utente che possiamo ordinare al massimo 15 numeri.
while i < numeri: #Impostiamo il primo ciclo dove i minore di numeri.
    print ('inserisci il numero', i+1 ) #Gli diciamo di inserire il primo numero.
    a[i] = int(input('')) #Il numero inserito andrà a ar parte degli elementi della lista creata.
    i=i+1 #Incrementiamo il contatore per far finire prima o poi il ciclo e a spostarci tra gli elemnti della lista.
l=0 #Inizializziamo la variabile per il secondo ciclo.
while l < numeri: #Impostiamo il secondo ciclo dove l minore di numeri.
    j=0 #Inizialissiamo il contantore per il ciclo annidato.
    while j < numeri-1 : #IMpostiamo il terzo ciclo annidato per j minore di numeri meno uno.
        if a[j] < a[j+1]: #Adesso facciamo una selezione dove l'elemento della lista in posizione j(posizione fornita dal contatore) è minore del numero situato nella stessa lista ma nella posizione j+1.
            scambio = a[j+1] #Nella variabile scambio mettiamo il valore nella posizione del contatore j+1.
            a[j+1] = a[j] #Andiamo ad assegnare al primo elemento a sinistra il valore che troviamo nella posizione j.
            a[j] = scambio #Adesso facciamo la stessa cosa pero' sta volta mettendo il valore di destra a quello di sinistra.
        j=j+1 #Incrementiamo il contatore j del primo ciclo per spostarci tra la lista e finrie il ciclo.
    l=l+1 #Incrementiamo il contatore l del secondo ciclo.
print ('i numeri ordinati in ordine decrescente sono') #Gli facciamo visualizzare una semplice frase.
i=0 #Inizializzamo il contantatore i per il seguente ciclo.
while i < numeri: #Impostiamo un ciclo dove i minore di numeri.
    print (a[i]) #Ogni volta grazie al contatore andiamo a stampare ogni elemento ordinato della lista.
    i=i+1 #Incrementiamo il contatore che ci fara da indice nella lista e per terminare il ciclo.

