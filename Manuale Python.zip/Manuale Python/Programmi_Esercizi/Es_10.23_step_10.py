def pitone(risposta):#Definiamo la funzione pitone.
    if risposta == '2': #Se la risposta e' uguale a 2.
        print ('Bravo, il nome viene dai comici inglesi Monty Python')#Ci congratuliamo per la risposta esatta.
    while risposta != '2': #Altrimenti se diverso da 2 facciamo un ciclo.
            print ('Hai sbagliato!') #Dove gli diciamo che ha sbagliato.
            #Proponiamo di nuovo le tre soluzioni.
            print ('1 Il nome viene da pitone ')
            print ('2 Il nome viene dai comici inglesi Monty Python ') 
            print ('3 Il nome viene da un personaggio di Harry Potter') 
            risposta = input('scegli 1,2 o 3 ') #Gli chiediamo di scegliere tra le tre rispose.
            if risposta == '2': #Se la risposta e' uguale a 2.
                print ('Bravo, il nome viene dai comici inglesi Monty Python') #Ci congratuliamo per la risposta esatta.
print ('Perché il linguaggio di programmazione di chiama Python?') #Adesso gli stampiamo la domanda.
#Stampiamo le tre possibili risposte tra cui una giusta.
print ('Ci sono 3 possibilità:')
print ('1 Il nome viene da pitone ')
print ('2 Il nome viene dai comici inglesi Monty Python ')
print ('3 Il nome viene da un personaggio di Harry Potter')
risposta = input('scegli 1,2 o 3 ') #Raccogliamo il suo input.
pitone(risposta)#Chiamiamo la funzione pitone.
