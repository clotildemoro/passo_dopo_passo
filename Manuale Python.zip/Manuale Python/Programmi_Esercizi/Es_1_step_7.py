numero = int(input ("Scrivi  un numero  ")) #Facciamo inserire un numero.
quadrato = numero ** 2 #Dentro quadrato andiamo a mette il numero elevato a 2.
cubo = numero ** 3 #Invece dentro cubo il numeor inserito elevato a 3.
print ("Il quadrato di ", numero, "e' ", quadrato) #Infine visualizziamo il risultato delle operazioni.
print ("Il cubo di ", numero, "e' ", cubo) #Infine andiamo a visualizzare il risultato delle oprazioni fatte.
