print ("Introduci le misure dei tre lati del triangolo in ordine crescente")
#Gli chiediamo di inserire in input le misure dei lati.
lato1 = int(input ("indica la misura del primo lato "))
lato2 = int(input ("indica la misura del secondo lato "))
lato3 = int(input ("indica la misura del terzo lato "))
if lato3 > lato1+lato2 or lato1 < lato3-lato2: #Verifichiamo le misure inserite.
	print ("con queste misure non e' possibile costruire un triangolo")
#Adesso iniziamo a verificare se il triangolo e' isoscele, equilatero o scaleno confrontando i lati.
if lato1 == lato2 and lato2 == lato3:
	print ("il triangolo e' equilatero")
else:
	if lato1 == lato2 or lato2 == lato3:
		print ("il triangolo e' isoscele")
	else:
		print ("il triangolo e' scaleno")
