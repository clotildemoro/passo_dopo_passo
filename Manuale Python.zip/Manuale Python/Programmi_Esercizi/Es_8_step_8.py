print ("vediamo come te la cavi con le addizioni") #Una semplice frase.
numero1 = int(input ("scrivi il primo addendo ")) #Facciamo inserire il primo addendo.
numero2 = int(input ("scrivi il secondo addendo ")) #Facciamo inserire il secondo addendo.
somma = int(input ("scrivi il risultato della somma ")) #Gli chiediamo di mettere anche il risultato
if somma == numero1+numero2: #Facciamo la somma dei due numeri e verifichiamo il risultato
        print ("bravo! risposta esatta") #Gli diciamo che e' stato bravo.
else: #Altrimenti.
	print ("la risposta e' sbagliata! ") #Gli diciamo che ha sbagliato.

