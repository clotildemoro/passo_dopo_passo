perimetro = 45*2 + 65*2 #Calcoliamo il perimetro del cortile.
print ("Il perimetro del cortile e' ", perimetro) #Gli diciamo il valore del perimetro.
base = int(input("Inserisci il valore della base ")) #Gli chiediamo di inserire l'area.
altezza = int(input("Inserisci il valore dell'altezza ")) #Gli chiediamo di inserire l'altezza.
perimetro = (base+altezza)*2 #Calcoliamo il perimetro con i dati forniti.
print ("Il perimetro del rettangolo di base ",base, "e altezza ",altezza,"e' ", perimetro) #Infine diamo il risultato dei calcoli.

