#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     27/02/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

a =1 #Impostiamo a zero la variabile a.
while a < 4 : #Adesso settiamo la condizione del ciclo con la seguente sintassi.
  print (a) #Stampiamo il contenuto della variabile a.
  a = a + 1 #Incrementiamo la variabile per non rendere il ciclo infinito.

