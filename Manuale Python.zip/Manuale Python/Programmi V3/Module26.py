#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

tabellina = [3,6,9,12,15,[10,20,30]] #Definiamo la lista tabellina e al suo interno mettiamo una lista nidificata.
print (tabellina [5]) #Andiamo a sampare a video la posizione 5 dove inizia la lista annidata e la stampa tutta.





