#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     08/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

amici = ["Gianni", "Luigi", "Carlo"] #Amici è una lista e' un insieme ordinato di valori di qualunque tipo in questo caso di nomi.
i = 0 #Inizializziamo la varibile contatore.
while i <3: #Impostiamo un ciclo con codizione i minore di 3.
  print (amici[i]) #Adesso andiamo a visualizzare il primo elemento di amici e ogni qual volta il contatore incrementa cambia elemento.
  i = i +1 #Incrementiamo il contatore.
