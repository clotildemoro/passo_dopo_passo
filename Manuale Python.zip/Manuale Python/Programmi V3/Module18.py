#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     07/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

print ("vengo \n \t subito \n \t \t a casa") #Mandiamo in stampa.
                                             #Con \t possiamo fare una tabulazione.
                                             #Con \n possiamo andare a capo.
