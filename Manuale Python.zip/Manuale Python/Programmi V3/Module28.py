#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

allievi = ["Luigi","Marco","Filippo","Paola","Gabriella","Silvia"] #Definiamo sempre la nostra lista.
for allievo in allievi: #Per ogni elementi in allievi.
	print ("Ora stampo l'allievo: ", allievo) #Metti in allievo ogni elemento e stampalo a video.





