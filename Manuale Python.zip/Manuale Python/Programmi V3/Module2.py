#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     22/02/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#stampa il triplo di un numero

numero=int(input("Introduci un numero ")) #Chiediamo in input un numero.
numero=numero*3 #Dentro numero andiamo a mettere il prodotto del numero inserito per 3.
print("Il triplo del numero introdotto e' ",numero) #Visualizziamo il contenuto di numero.
