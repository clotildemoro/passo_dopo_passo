#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

allievi_4E = [["Bianchi","Gabriele"],["Verdi","Alessandro"],["Rossi","Anna"],["Neri","Michela"],["Viola","Antonio"]] #Dichiariamo la lista allievi_4E con tante sottoliste annidate.
print (allievi_4E [2]) #Si va a stampare la sottolista in posizione due.






