#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

allievi=["Luigi","Marco","Filippo","Paola","Gabriella","Silvia"] #Dichiariamo e definiamo gli elementi della lista allievi.
i = 0 #Inizializziamo la variabile contatore.
while i < len(allievi): #Impostiamo in ciclo dove i deve essere minori della lunghezza della lista allievi usando il comando len.
	print (allievi[i], end=" ") #Andiamo a visualizzare il contenuti di allievi utilizzando il contatore che ad ogni incremento cambia elemento e stampa.
	i = i + 1 #Incremento la varibile contatore.

