#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     27/02/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import math #Importo la libreria necessaria per eseguire le operazioni matematiche.

numero = float(input("Scrivi un numero ")) #Faccio inserire dall'utente il numero a suo piacere.

print ("La radice quadrata di", numero,"e'", math.sqrt(numero)) #Facciamo la radice quadrata del numero inserito.
