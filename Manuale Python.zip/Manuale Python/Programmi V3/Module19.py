#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     06/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

squadra = "Juventus" #Dentro la scatola mettiamo la stringa Juventus.
messaggio = "VIVA" + " " + squadra[0] + squadra[1] + squadra[2] + squadra[3] #Dentro messaggio mettiamo la scritta viva concatenata tramite il + alla variabile precendente pero' prendendo lettara per lettara inserendo la posizione dentro le parentesi quadre.
print (squadra) #A questo punto andiamo a far visualizza il contenuto di squadra.
print (messaggio) #Adesso invece stampiamo il semplice messaggio viva ma anche le prime quattro lettere della squadra Juve.

