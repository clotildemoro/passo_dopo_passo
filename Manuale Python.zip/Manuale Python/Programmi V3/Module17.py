#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     07/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

print ("vengo \n \t subito \n \t \t a casa") #Facciamo una stampa di questa frase.
                                             #Il comando \n serve per andare a capo.
                                             #Il comando \t serve per fare una tabulazione.
