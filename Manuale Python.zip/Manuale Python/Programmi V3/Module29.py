#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

i = int(input("Inserisci un numero: ")) #Facciamo inserire un numero dall'utente.
while i < 200: #Mettiamo un ciclo con una condizione i minore di 200.
    if i == 0: #Una selezione dove se i e' uguale a 0.
        break #Ferma la selezione.	  
print ("Il numero e': ", i) #Finiamo  con la visulaizzazione del numero.
print ("Finito") #E gli diciamo che e' finito il programma.
