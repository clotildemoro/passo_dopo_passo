#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     22/02/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

#COn il simbolo della percentuale chiamato modulo quando andiamo ad eseguire il programmo ci da solo il resto della divione tra i due numeri.

r = 6 % 3 #Dentro la scatola r andiamo a mettere SOLO il resto della divione tra 6 e 3 quando verra' eseguito.
f = 7 % 3 #Dentro la scatola f andiamo a mettere SOLO il resto della divione tra 7 e 3 quando verra' eseguito.
print(r) #Andiamo a visualizzare il contenuto di r.
print(f) #andiamo a visualizzare il contenuto di f.