#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

allievi_4E = ["Gabriele","Alessandro","Anna","Michela","Antonio"] #Definiamo sempre la lista e i suoi elementi.
print (allievi_4E  [:4]) #Andiamo a stampare il contenuto della lista ma dalla posizione zero compresa alla posizione 4 compresa.
print (allievi_4E  [3:]) #Qui invece stampiamo dalla posizione numero tre fino all'ultima posizione.
print (allievi_4E  [:] ) #In questo caso invece visualizzeremo la prima e l'ultima posizione comprese.




