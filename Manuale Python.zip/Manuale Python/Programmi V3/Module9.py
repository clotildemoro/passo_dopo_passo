#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     07/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

i=1 #Andiamo sempre ad assegnare alla variabile del ciclo un valore.
while i != 0 : #Si imposta il ciclo dove i e' diverso da 0.
    print ("Aiuto! Non mi fermo piu'.") #Nel corpo del ciclo abbiamo la frase da far visualizzare.
    i = i + 1 #Incrementiamo la variabile.

