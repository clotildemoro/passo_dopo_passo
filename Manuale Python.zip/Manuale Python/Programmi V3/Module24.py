#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Aurora
#
# Created:     11/03/2013
# Copyright:   (c) Aurora 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

allievi_3A = ["Luigi","Marco","Filippo","Paola","Gabriella","Silvia"] #Dichiariamo la lista e definiamo gli elementi.
allievi_4E = ["Gabriele","Alessandro","Anna","Michela","Antonio"] #Dichiariamo la lista e definiamo gli elementi.
allievi = allievi_3A + allievi_4E #Sommiamo i contenuti della lista 1 e quelli della lista due e mettiamo il contenuto nella variabile allevi.
print (allievi) #Stampiamo il contenuto di allievi quindi l'unione della prima e seconda lista dichiarate.


