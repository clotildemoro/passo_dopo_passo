nome = input ("Scrivi il tuo nome ")
utente = input ("Sei femmina? ")
if utente == "si":
	print ("Cara ", nome, ", sei bravissima!")
if utente == "no":
	print ("Caro ", nome, ", sei bravissimo!")
