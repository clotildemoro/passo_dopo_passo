x =  float(input("scrivi la x\n"))
y =  float(input("scrivi la y\n"))
if y == 0:
    print ("la divisione è impossibile")
else:
    d = x/y
    print ("x diviso y è uguale a", d)
