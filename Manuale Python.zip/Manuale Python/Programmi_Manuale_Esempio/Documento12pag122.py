import pygame
import time
pygame.init ()
areapalloncino = pygame.display.set_mode ((400,500))
i = 0 
while i < 600:
    pygame.draw.circle (areapalloncino, (255,0,0), (300,350-i), 30) 
    pygame.draw.line(areapalloncino,(255,255,0),(300,380-i),(300, 580-i))
    pygame.display.update ()
    time.sleep (0.03)
    areapalloncino.fill ((255,255,255))
    i = i + 1
i = 0	
while i< 600: #disegna il palloncino spostato di i pixel verso l'alto
      pygame.display.update ()
      time.sleep (0.03)
      areapalloncino.fill ((255,255,255))
      i = i + 1						
